package in.sp.main.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.validation.annotation.Validated;

import in.sp.main.beans.Student;
import in.sp.main.dao.StudentDao;

@Service
public class StudentServiceImpl implements StudentService {

    @Autowired
    private StudentDao studentDao;
    
    @Override
    @Transactional
    public Student addStudent(@Validated Student std) {
        // Input validation for required fields
        if (std.getName() == null || std.getName().isEmpty()) {
            throw new IllegalArgumentException("Student name cannot be empty");
        }
        Student student = studentDao.save(std);
        return student;
    }

    @Override
    @Transactional(readOnly = true)
    public List<Student> getAllStudent() {
        return studentDao.findAll();
    }

    @Override
    @Transactional(readOnly = true)
    public Student getStudentDetails(int id) {
        Optional<Student> optional = studentDao.findById(id);
        if (optional.isPresent()) {
            return optional.get();
        } else {
            throw new IllegalArgumentException("Student not found with ID: " + id);
        }
    }

    @Override
    @Transactional
    public Student updateStudent(@Validated Student std) {
       
        if (std.getName() == null || std.getName().isEmpty()) {
            throw new IllegalArgumentException("Student name cannot be empty");
        }
        Student student = studentDao.save(std);
        return student;
    }

    @Override
    @Transactional
    public boolean deleteStudent(int id) {
        try {
            studentDao.deleteById(id);
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
}
