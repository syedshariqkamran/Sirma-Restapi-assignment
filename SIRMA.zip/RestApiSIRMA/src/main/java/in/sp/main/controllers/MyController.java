package in.sp.main.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import in.sp.main.beans.Student;
import in.sp.main.services.StudentService;

@RestController
public class MyController {

    @Autowired
    private StudentService studentService;

    @PostMapping("/student")
    public Student addStudent(@Validated @RequestBody Student std) {
        // Perform additional validation or business logic if needed
        Student student = studentService.addStudent(std);
        return student;
    }

    @GetMapping("/student")
    public List<Student> getAllStudents() {
        return studentService.getAllStudent();
    }

    @GetMapping("/student/{id}")
    public Student getStudentDetails(@PathVariable("id") int id) {
        Student std = studentService.getStudentDetails(id);
        if (std == null) {
            throw new ResourceNotFoundException("Student not found with ID: " + id);
        }
        return std;
    }

    @PutMapping("/student")
    public Student updateStudent(@Valid @RequestBody Student std) {
        // Perform additional validation or business logic if needed
        Student student = studentService.updateStudent(std);
        return student;
    }

    @DeleteMapping("/student/{id}")
    public boolean deleteStudent(@PathVariable("id") int id) {
        boolean status = studentService.deleteStudent(id);
        if (!status) {
            throw new RuntimeException("Failed to delete student with ID: " + id);
        }
        return status;
    }

    
    @ExceptionHandler(ResourceNotFoundException.class)
    public ResponseEntity<Object> handleResourceNotFoundException(ResourceNotFoundException ex) {
        
        ErrorResponse error = new ErrorResponse(HttpStatus.NOT_FOUND, ex.getMessage());
        return new ResponseEntity<>(error, HttpStatus.NOT_FOUND);
    }

    
    @ExceptionHandler(Exception.class)
    public ResponseEntity<Object> handleGenericException(Exception ex) {
      
        ErrorResponse error = new ErrorResponse(HttpStatus.INTERNAL_SERVER_ERROR, "Internal Server Error");
        return new ResponseEntity<>(error, HttpStatus.INTERNAL_SERVER_ERROR);
    }

    
    static class ErrorResponse {
        private final HttpStatus status;
        private final String message;

        public ErrorResponse(HttpStatus status, String message) {
            this.status = status;
            this.message = message;
        }

        public HttpStatus getStatus() {
            return status;
        }

        public String getMessage() {
            return message;
        }
    }
}
